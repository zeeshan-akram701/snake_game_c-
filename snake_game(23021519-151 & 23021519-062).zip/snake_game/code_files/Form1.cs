using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;

namespace SnakeWinForms
{
    public partial class Form1 : Form
    {
        // Grid settings
        private const int GridCols = 30;    // >= 20 required
        private const int GridRows = 30;    // >= 20 required
        private const int CellSize = 16;    // pixels per cell

        // Game state
        private List<Point> snake;          // head is snake[0]
        private Point food;
        private Direction currentDirection;
        private Direction nextDirection;
        private Random rnd = new Random();
        private int score;
        private int highScore = 0;         // session high-score
        private bool gameActive = false;
        private bool gamePaused = false;
        private bool gameOver = false;

        // Timer speed (ms)
        private int gameSpeed = 120;// initial; lower = faster

        public Form1()
        {
            InitializeComponent();
            InitGameArea();
            ResetGame();
        }

        private void InitGameArea()
        {
            // Panel for drawing
            gamePanel.Width = GridCols * CellSize + 1;
            gamePanel.Height = GridRows * CellSize + 1;
            this.ClientSize = new Size(gamePanel.Right + 20, Math.Max(gamePanel.Bottom + 20, 300));

            // Make drawing smooth
            gamePanel.Paint += GamePanel_Paint;
            gamePanel.DoubleBuffered(true);

            // Key handling
            this.KeyPreview = true;
            this.KeyDown += Form1_KeyDown;

            // Timer
            gameTimer.Interval = gameSpeed;
            gameTimer.Tick += GameTimer_Tick;
            gameTimer.Enabled = false;

            // Buttons
            btnStart.Click += BtnStart_Click;
            btnPauseResume.Click += BtnPauseResume_Click;
            btnRestart.Click += BtnRestart_Click;

            UpdateScoreLabels();
            ShowStartScreen();
        }

        private void ShowStartScreen()
        {
            gameTimer.Stop();
            gameActive = false;
            gamePaused = false;
            gameOver = false;
            lblState.Text = "Ready";
            btnPauseResume.Text = "Pause";
            gamePanel.Invalidate();
        }

        private void ResetGame()
        {
            snake = new List<Point>();
            // Start with 3 segments centered
            int startX = GridCols / 2;
            int startY = GridRows / 2;
            snake.Add(new Point(startX, startY));
            snake.Add(new Point(startX - 1, startY));
            snake.Add(new Point(startX - 2, startY));

            currentDirection = Direction.Right;
            nextDirection = Direction.Right;
            score = 0;
            gameSpeed = 120;
            gameTimer.Interval = gameSpeed;

            PlaceFood();
            gameOver = false;
            gameActive = false;
            gamePaused = false;
            UpdateScoreLabels();
            gamePanel.Invalidate();
        }

        private void StartGame()
        {
            if (gameOver)
            {
                ResetGame();
            }

            gameActive = true;
            gamePaused = false;
            gameOver = false;
            gameTimer.Interval = gameSpeed;
            gameTimer.Start();
            lblState.Text = "Playing";
        }

        private void PauseGame()
        {
            if (!gameActive || gameOver) return;
            gamePaused = true;
            gameTimer.Stop();
            lblState.Text = "Paused";
        }

        private void ResumeGame()
        {
            if (!gameActive || gameOver) return;
            gamePaused = false;
            gameTimer.Start();
            lblState.Text = "Playing";
        }

        private void GameOver()
        {
            gameTimer.Stop();
            gameOver = true;
            gameActive = false;
            if (score > highScore) highScore = score;
            UpdateScoreLabels();
            lblState.Text = "Game Over";
            // Show game over message area
            MessageBox.Show($"Game Over!\nYour score: {score}", "Game Over", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void PlaceFood()
        {
            // pick random empty cell
            List<Point> empty = new List<Point>();
            for (int x = 0; x < GridCols; x++)
            {
                for (int y = 0; y < GridRows; y++)
                {
                    Point p = new Point(x, y);
                    if (!snake.Contains(p))
                        empty.Add(p);
                }
            }

            if (empty.Count == 0)
            {
                // player filled the board
                GameOver();
                return;
            }

            food = empty[rnd.Next(empty.Count)];
        }

        private void GameTimer_Tick(object sender, EventArgs e)
        {
            if (!gameActive || gamePaused || gameOver) return;

            // Accept nextDirection (but prevent instant reverse)
            if (!IsOpposite(nextDirection, currentDirection))
                currentDirection = nextDirection;

            // Compute next head
            Point head = snake[0];
            Point next = head;
            switch (currentDirection)
            {
                case Direction.Up: next = new Point(head.X, head.Y - 1); break;
                case Direction.Down: next = new Point(head.X, head.Y + 1); break;
                case Direction.Left: next = new Point(head.X - 1, head.Y); break;
                case Direction.Right: next = new Point(head.X + 1, head.Y); break;
            }

            // Check wall collision
            if (next.X < 0 || next.X >= GridCols || next.Y < 0 || next.Y >= GridRows)
            {
                GameOver();
                gamePanel.Invalidate();
                return;
            }

            // Check self-collision
            if (snake.Contains(next))
            {
                GameOver();
                gamePanel.Invalidate();
                return;
            }

            // Move snake: add new head
            snake.Insert(0, next);

            // Check food
            if (next == food)
            {
                score += 10;
                UpdateScoreLabels();
                PlaceFood();
                // Optionally increase speed as score grows (levels)
                if (score % 50 == 0 && gameSpeed > 40)
                {
                    gameSpeed -= 10;
                    gameTimer.Interval = gameSpeed;
                }
            }
            else
            {
                // remove tail
                snake.RemoveAt(snake.Count - 1);
            }

            gamePanel.Invalidate();
        }

        private void UpdateScoreLabels()
        {
            lblScore.Text = $"Score: {score}";
            lblHighScore.Text = $"High Score: {highScore}";
        }

        private void GamePanel_Paint(object sender, PaintEventArgs e)
        {
            var g = e.Graphics;
            // background
            g.Clear(Color.FromArgb(240, 240, 240));

            // draw grid (optional subtle lines)
            using (var gridPen = new Pen(Color.FromArgb(230, 230, 230)))
            {
                for (int x = 0; x <= GridCols; x++)
                    g.DrawLine(gridPen, x * CellSize, 0, x * CellSize, GridRows * CellSize);
                for (int y = 0; y <= GridRows; y++)
                    g.DrawLine(gridPen, 0, y * CellSize, GridCols * CellSize, y * CellSize);
            }

            // draw food (only if valid)
            if (food != null)
            {
                Rectangle foodRect = new Rectangle(food.X * CellSize + 1, food.Y * CellSize + 1, CellSize - 1, CellSize - 1);
                using (Brush b = new SolidBrush(Color.Red))
                    g.FillEllipse(b, foodRect);
            }

            // draw snake
            for (int i = 0; i < snake.Count; i++)
            {
                var p = snake[i];
                Rectangle rect = new Rectangle(p.X * CellSize + 1, p.Y * CellSize + 1, CellSize - 1, CellSize - 1);
                if (i == 0)
                {
                    using (Brush headBrush = new SolidBrush(Color.FromArgb(20, 130, 20)))
                        g.FillRectangle(headBrush, rect);
                }
                else
                {
                    using (Brush bodyBrush = new SolidBrush(Color.FromArgb(60, 180, 60)))
                        g.FillRectangle(bodyBrush, rect);
                }
            }

            // If not started show overlay instructions
            if (!gameActive && !gameOver)
            {
                string text = "Press START to play\nArrow keys to move\nCannot reverse direction instantly";
                var font = new Font("Arial", 10);
                var sz = g.MeasureString(text, font);
                var x = (gamePanel.Width - sz.Width) / 2;
                var y = (gamePanel.Height - sz.Height) / 2;
                using (Brush bg = new SolidBrush(Color.FromArgb(200, Color.White)))
                {
                    g.FillRectangle(bg, x - 10, y - 10, sz.Width + 20, sz.Height + 20);
                }
                using (Brush fg = new SolidBrush(Color.Black))
                {
                    g.DrawString(text, font, fg, x, y);
                }
            }

            // If paused overlay
            if (gamePaused)
            {
                string text = "PAUSED";
                var font = new Font("Arial", 24, FontStyle.Bold);
                var sz = g.MeasureString(text, font);
                var x = (gamePanel.Width - sz.Width) / 2;
                var y = (gamePanel.Height - sz.Height) / 2;
                using (Brush fg = new SolidBrush(Color.FromArgb(180, 0, 0, 0)))
                    g.DrawString(text, font, fg, x, y);
            }

            // If game over overlay
            if (gameOver)
            {
                string text = $"GAME OVER\nScore: {score}";
                var font = new Font("Arial", 18, FontStyle.Bold);
                var sz = g.MeasureString(text, font);
                var x = (gamePanel.Width - sz.Width) / 2;
                var y = (gamePanel.Height - sz.Height) / 2;
                using (Brush bg = new SolidBrush(Color.FromArgb(220, Color.White)))
                    g.FillRectangle(bg, x - 10, y - 10, sz.Width + 20, sz.Height + 20);
                using (Brush fg = new SolidBrush(Color.Black))
                    g.DrawString(text, font, fg, x, y);
            }
        }

        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            if (!gameActive && !gameOver)
            {
                // allow starting with keyboard
                if (e.KeyCode == Keys.Up || e.KeyCode == Keys.Down || e.KeyCode == Keys.Left || e.KeyCode == Keys.Right)
                {
                    StartGame();
                }
            }

            if (!gameActive || gamePaused || gameOver) return;

            if (e.KeyCode == Keys.Up)
                AttemptChangeDirection(Direction.Up);
            else if (e.KeyCode == Keys.Down)
                AttemptChangeDirection(Direction.Down);
            else if (e.KeyCode == Keys.Left)
                AttemptChangeDirection(Direction.Left);
            else if (e.KeyCode == Keys.Right)
                AttemptChangeDirection(Direction.Right);
        }

        private void AttemptChangeDirection(Direction dir)
        {
            // Prevent instant reverse
            if (!IsOpposite(dir, currentDirection))
            {
                nextDirection = dir;
            }
        }

        private bool IsOpposite(Direction a, Direction b)
        {
            return (a == Direction.Left && b == Direction.Right)
                || (a == Direction.Right && b == Direction.Left)
                || (a == Direction.Up && b == Direction.Down)
                || (a == Direction.Down && b == Direction.Up);
        }

        private void BtnStart_Click(object sender, EventArgs e)
        {
            if (!gameActive)
            {
                StartGame();
            }
        }

        private void BtnPauseResume_Click(object sender, EventArgs e)
        {
            if (!gameActive) return;
            if (gamePaused)
            {
                ResumeGame();
                btnPauseResume.Text = "Pause";
            }
            else
            {
                PauseGame();
                btnPauseResume.Text = "Resume";
            }
        }

        private void BtnRestart_Click(object sender, EventArgs e)
        {
            ResetGame();
            StartGame();
            btnPauseResume.Text = "Pause";
        }
    }

    public enum Direction
    {
        Up, Down, Left, Right
    }



    // Simple extension to set DoubleBuffered on a Control (reflection)
    public static class ControlExtensions
    {
        public static void DoubleBuffered(this Control c, bool enable)
        {
            var prop = typeof(Control).GetProperty("DoubleBuffered",
                    System.Reflection.BindingFlags.NonPublic | System.Reflection.BindingFlags.Instance);
            if (prop != null)
                prop.SetValue(c, enable, null);
        }
    }
}
