﻿namespace SnakeWinForms
{
    partial class Form1
    {
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.Panel gamePanel;
        private System.Windows.Forms.Timer gameTimer;
        private System.Windows.Forms.Label lblScore;
        private System.Windows.Forms.Label lblHighScore;
        private System.Windows.Forms.Button btnStart;
        private System.Windows.Forms.Button btnPauseResume;
        private System.Windows.Forms.Button btnRestart;
        private System.Windows.Forms.Label lblState;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            gamePanel = new Panel();
            gameTimer = new System.Windows.Forms.Timer(components);
            lblScore = new Label();
            lblHighScore = new Label();
            btnStart = new Button();
            btnPauseResume = new Button();
            btnRestart = new Button();
            lblState = new Label();
            SuspendLayout();
            // 
            // gamePanel
            // 
            gamePanel.BackColor = Color.White;
            gamePanel.BorderStyle = BorderStyle.FixedSingle;
            gamePanel.Location = new Point(12, 12);
            gamePanel.Name = "gamePanel";
            gamePanel.Size = new Size(480, 480);
            gamePanel.TabIndex = 0;
            // 
            // gameTimer
            // 
            gameTimer.Interval = 120;
            // 
            // lblScore
            // 
            lblScore.AutoSize = true;
            lblScore.Location = new Point(510, 20);
            lblScore.Name = "lblScore";
            lblScore.Size = new Size(75, 25);
            lblScore.TabIndex = 1;
            lblScore.Text = "Score: 0";
            // 
            // lblHighScore
            // 
            lblHighScore.AutoSize = true;
            lblHighScore.Location = new Point(510, 45);
            lblHighScore.Name = "lblHighScore";
            lblHighScore.Size = new Size(118, 25);
            lblHighScore.TabIndex = 2;
            lblHighScore.Text = "High Score: 0";
            // 
            // btnStart
            // 
            btnStart.Location = new Point(510, 90);
            btnStart.Name = "btnStart";
            btnStart.Size = new Size(100, 30);
            btnStart.TabIndex = 3;
            btnStart.Text = "Start";
            btnStart.UseVisualStyleBackColor = true;
            // 
            // btnPauseResume
            // 
            btnPauseResume.Location = new Point(510, 130);
            btnPauseResume.Name = "btnPauseResume";
            btnPauseResume.Size = new Size(100, 30);
            btnPauseResume.TabIndex = 4;
            btnPauseResume.Text = "Pause";
            btnPauseResume.UseVisualStyleBackColor = true;
            // 
            // btnRestart
            // 
            btnRestart.Location = new Point(510, 170);
            btnRestart.Name = "btnRestart";
            btnRestart.Size = new Size(100, 30);
            btnRestart.TabIndex = 5;
            btnRestart.Text = "Restart";
            btnRestart.UseVisualStyleBackColor = true;
            // 
            // lblState
            // 
            lblState.AutoSize = true;
            lblState.Location = new Point(510, 65);
            lblState.Name = "lblState";
            lblState.Size = new Size(60, 25);
            lblState.TabIndex = 6;
            lblState.Text = "Ready";
            // 
            // Form1
            // 
            ClientSize = new Size(1007, 520);
            Controls.Add(lblState);
            Controls.Add(btnRestart);
            Controls.Add(btnPauseResume);
            Controls.Add(btnStart);
            Controls.Add(lblHighScore);
            Controls.Add(lblScore);
            Controls.Add(gamePanel);
            KeyPreview = true;
            Name = "Form1";
            Text = "Snake - C# WinForms";
            ResumeLayout(false);
            PerformLayout();
        }

        protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
        {
            if (gameActive && !gamePaused && !gameOver)
            {
                if (keyData == Keys.Up)
                    AttemptChangeDirection(Direction.Up);
                else if (keyData == Keys.Down)
                    AttemptChangeDirection(Direction.Down);
                else if (keyData == Keys.Left)
                    AttemptChangeDirection(Direction.Left);
                else if (keyData == Keys.Right)
                    AttemptChangeDirection(Direction.Right);

                return true; // mark as handled
            }

            return base.ProcessCmdKey(ref msg, keyData);
        }

        #endregion
    }
}
